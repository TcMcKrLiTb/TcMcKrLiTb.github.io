define(["exports"],(function(n){"use strict";n.encodePath=function(n){return void 0===n&&(n=""),n.split("/").map(encodeURIComponent).join("/")}}));
